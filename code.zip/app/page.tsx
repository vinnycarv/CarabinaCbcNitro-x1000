import { ProductPage } from '@/components/product-page'

export default function Page() {
  return <ProductPage />
}
